﻿define("epi-cms/contentediting/editors/_ClipboardPasteMixin", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/event",
    "dojo/_base/lang",
    "dojo/_base/window",

    "dojo/dom-attr",
    "dojo/dom-class",
    "dojo/dom-construct",

    "dojo/on",
    "dojo/query",
    "dojo/_base/kernel",
// dijit
    "dijit/Destroyable",
// epi
    "epi/string"
],

function (
// dojo
    array,
    declare,
    event,
    lang,
    window,

    domAttr,
    domClass,
    domConstruct,

    on,
    query,
    kernel,
// dijit
    Destroyable,
// epi
    epiString
) {

    return declare(Destroyable, {
        // description:
        //      Enable clipboard paste function that can process clipboard data for all browsers.
        // tags:
        //      internal

        // _editingKey: [private] String
        //      The key that used to make editing points are unique for each instance of the content editable.
        _editingKey: "",

        // _editingNode: [private] DOM
        //      The current editing element, that had "contenteditable" attribute is TRUE.
        _editingNode: null,

        // _editingContainer: [private] DOM
        //      The parent element of the given editing element.
        _editingContainer: null,

        // _beginEditingPoint: [private] DOM
        //      The DOM node that will place before the editing element
        _beginEditingPoint: null,

        // _endEditingPoint: [private] DOM
        //      The DOM node that will place after the editing element
        _endEditingPoint: null,

        // _pasteEventActive: [private] Boolean
        //      Flag indicated that paste action (Ctrl+V or paste from context menu) fired or not.
        _pasteEventActive: false,

        // _editingCSSClass: [private] String
        //      CSS class used for query purpose
        _editingCSSClass: "epi-content-editable-container",

        // _beginEditingPointCSSClass: [private] String
        //      CSS class used for query purpose. Marked as the start point to find the new pasted nodes.
        _beginEditingPointCSSClass: "epi-content-editable-begin-edit",

        // _endEditingPointCSSClass: [private] String
        //      CSS class used for query purpose. Marked as the end point to find the new pasted nodes.
        _endEditingPointCSSClass: "epi-content-editable-end-edit",

        // _endSuffix: [private] String
        //      Represents a mark to indicate ending of the content when processing paste.
        _endSuffix: "###epiendtext",

        canAccessClipboard: function (/*Event*/evt) {
            // summary:
            //      Verify that the current browser supports to access clipboard data.
            // evt: [Event]
            //      The source event object
            // tags:
            //      public

            return !!this.getClipboard(evt);
        },

        getClipboard: function (/*Event*/evt) {
            // summary:
            //      Get clipboard object
            // evt: [Event]
            //      The source event object
            // tags:
            //      public

            return (evt && evt.clipboardData) || window.global.clipboardData;
        },

        getClipboardData: function (/*Event*/evt) {
            // summary:
            //      Get clipboard data
            // evt: [Event]
            //      The source event object
            // tags:
            //      public

            var clipboard = this.getClipboard(evt);
            return (clipboard && window.global.clipboardData) ? clipboard.getData("Text") : clipboard.getData("text/plain");
        },

        destroy: function () {
            // summary:
            //      Destroy all redundant nodes after paste and process paste data
            // tags:
            //      public, extension

            this.inherited(arguments);

            this._destroyRedundantNodes([
                this._beginEditingPoint || this._getEditingPoint("before"),
                this._endEditingPoint || this._getEditingPoint("after")
            ]);

            this._editingNode = this._editingContainer = this._beginEditingPoint = this._endEditingPoint = null;
        },

        pasteMixinSetup: function (/*String*/editingKey, /*DOM*/editingElement) {
            // summary:
            //      Setup clipboard paste functions.
            // editingKey: [String]
            //      Key used in manual paste process.
            // editingElement: [DOM]
            //      The given content editing element.
            // tags:
            //      public

            if (!editingElement) {
                return;
            }

            this._editingKey = editingKey;
            this._editingNode = editingElement;
            this._editingContainer = this._editingNode.parentNode;

            this.own(
                on(this._editingNode, "beforepaste", lang.hitch(this, this._onBeforePaste)),
                on(this._editingNode, "paste", lang.hitch(this, this._onPaste)),
                on(this._editingNode, "input", lang.hitch(this, this._onInput))
            );
        },

        _onBeforePaste: function (/*Event*/evt) {
            // summary:
            //      [IE browser only] Process clipboard data before it paste to the target element
            // evt: [Event]
            //      onbeforepaste event
            // tags:
            //      private

            if (this.canAccessClipboard(evt) && window.global.clipboardData) {
                this.getClipboard(evt).setData("Text", epiString.stripHtmlTags(this.getClipboardData(evt)));
            }
        },

        _onPaste: function (/*Event*/evt) {
            // summary:
            //      Process clipboard data before it paste to the target element
            // evt: [Event]
            //      The onpaste event object
            // tags:
            //      private

            if (window.global.clipboardData) {
                return;
            }

            if (this.canAccessClipboard(evt)) {
                this._processNativePaste(evt);

                // Stop onpaste event in order to get clipboard data to process
                event.stop(evt);

                return;
            }

            this._setupManualPaste();
        },

        _onInput: function (/*Event*/evt) {
            // summary:
            //      If the current browser do not support to access clipboard data, process the pasted data on the editing element
            // evt: [Event]
            //      The input event object
            // tags:
            //      private

            if (this.canAccessClipboard(evt) || !this._pasteEventActive) {
                return;
            }

            this._processManualPaste();
        },

        _setupManualPaste: function () {
            // summary:
            //      Setup stub for manual paste (can not access clipboard data from running browser)
            // tags:
            //      private

            kernel.deprecated("_setupManualPaste(...)", 'Fallback is no longer needed in supported browsers', "EPiServer 8.0");

            this._pasteEventActive = true;

            this._preparePastePosition();

            this._setupEditingPoints();
        },

        _processNativePaste: function (/*Event*/evt) {
            // summary:
            //      Setup stub for native paste (supported access clipboard data running browser)
            // evt: [Event]
            //      The onpaste event object
            // tags:
            //      private

            var ownerDocument = this._editingNode.ownerDocument,
                textContent = epiString.stripHtmlTags(this.getClipboardData(evt));

            // Call document.execCommand to paste the clean data to the target element
            if (!epiString.isNullOrEmpty(textContent)) {
                ownerDocument.execCommand("insertText", false, textContent);
            }
        },

        _processManualPaste: function () {
            // summary:
            //      Process the pasted data on the editing element.
            //      Strip all HTML tags from the pasted data, re-format the rendered HTML blocks.
            // tags:
            //      private

            this._pasteEventActive = false;

            domClass.add(this._editingNode, this._editingCSSClass);

            var renderedNodes = this._getRenderedNodes();
            if (renderedNodes instanceof Array && renderedNodes.length > 0) {
                renderedNodes.length === 1 ? this._processPasteNormalContent() : this._processPasteAbnormalContent(renderedNodes);

                this._destroyRedundantNodes(this._getRedundantNodes(renderedNodes));
            }
        },

        _processPasteNormalContent: function () {
            // summary:
            //      Process pasted content for normal content case.
            //      It mean that, not any extra nodes generated after paste action.
            // tags:
            //      private
            kernel.deprecated("_processPasteNormalContent(...)", 'Fallback is no longer needed in supported browsers', "EPiServer 8.0");

            this._editingNode.textContent = this._editingNode.textContent; // Clean all un-printable characters
            this._setCaretPosition(this._editingNode, this._startAt); // Restore the caret position

            var endAt = epiString.isNullOrEmpty(this._contentEnd)
                ? this._editingNode.textContent.length
                : this._editingNode.textContent.indexOf(lang.trim(this._contentEnd));

            var currentContent = this._editingNode.textContent,
                contentBegin = currentContent.substring(0, this._startAt),
                pastedContent = currentContent.substring(this._startAt, endAt),
                cleanContent = epiString.stripHtmlTags(pastedContent);

            this._editingNode.textContent = contentBegin + cleanContent + this._contentEnd.substring(0, this._contentEnd.length - this._endSuffix.length);

            // Set the caret to correct position after pasted
            this._setCaretPosition(this._editingNode, (contentBegin + cleanContent).length);
        },

        _processPasteAbnormalContent: function (/*Array*/abnormalNodes) {
            // summary:
            //      Process content after paste action for abnormal content case.
            //      Abnormal content here is the content that have some HTML tags that will break the rendering of the container node.
            // abnormalNodes: [Array]
            //      Collection of the rendered DOM nodes after pasted
            // tags:
            //      private

            var processedContent = abnormalNodes.map(function (item) {
                if (domAttr.get(item, "contenteditable") === "true" && domClass.contains(item, "epi-editContainer")) {
                    return item.textContent;
                }

                return epiString.stripHtmlTags(item.innerText || item.textContent);
            }).join("");

            this._editingNode.textContent = processedContent.substring(0, processedContent.length - this._endSuffix.length);
        },

        _setCaretPosition: function (/*DOM*/activeElement, /*Integer*/endAt) {
            // summary:
            //      Set caret at the given position
            // activeElement: [DOM]
            //      The current editing DOM node
            // endAt: [Integer]
            //      The latest position of the pointer after pasted
            // tags:
            //      private

            var ownerDocument = activeElement.ownerDocument,
                range = ownerDocument.createRange(),
                selection = ownerDocument.getSelection();

            if (activeElement.lastChild) {
                endAt = Math.min(activeElement.lastChild.textContent.length, endAt);
                range.setStart(activeElement.lastChild, endAt);
            }

            range.collapse(true);

            selection.removeAllRanges();
            selection.addRange(range);
        },

        _preparePastePosition: function () {
            // summary:
            //      Get start position of the caret before pasted
            // tags:
            //      private
            kernel.deprecated("_preparePastePosition(...)", 'Fallback is no longer needed in supported browsers', "EPiServer 8.0");

            var selection = this._editingNode.ownerDocument.getSelection(),
                currentContent = this._editingNode.textContent;

            // Remove the marked content
            selection.deleteFromDocument();
            selection.collapseToStart();

            if (selection.anchorNode.nodeType !== document.TEXT_NODE) {
                // When caret is at the end of text content, the found selection can be ELEMENT_NODE
                // So we need to focus to the text content and get the selection again
                this._editingNode.textContent && this._setCaretPosition(this._editingNode, currentContent.length);
                selection = this._editingNode.ownerDocument.getSelection();
            }

            this._startAt = selection.anchorOffset;

            // Add a special string to identify the ending text
            this._editingNode.textContent = currentContent = this._editingNode.textContent + this._endSuffix;

            // Restore the caret position before pasted content is inserted
            this._setCaretPosition(this._editingNode, this._startAt);

            // Save the end part of existing text content
            this._contentEnd = this._editingNode.textContent.substring(this._startAt, currentContent.length);
        },

        _getRenderedNodes: function () {
            // summary:
            //      Get the DOM nodes that rendered after paste function
            // tags:
            //      private

            var nextElements = query("span." + this._getEditingPointClass("before"), this._editingContainer).nextAll(),
                nextElement = null,
                renderedNodes = [];

            nextElements.some(function (item) {
                if (item === this._endEditingPoint) {
                    return true;
                }

                renderedNodes.push(item);
            }, this);

            return renderedNodes;
        },

        _getRedundantNodes: function (/*Array*/renderedNodes) {
            // summary:
            //      Get the redundant DOM nodes (automatically rendered by browser if the pasted data include some special HTML tags) from the given rendered DOM nodes
            // renderedNodes: [Array]
            //      Collection of DOM nodes that rendered after paste
            // tags:
            //      private

            // Get all DOM nodes that do not have the editing CSS class
            var redundantNodes = renderedNodes.filter(function (item) {
                return !domClass.contains(item, this._editingCSSClass);
            }, this);

            // Get all DOM nodes that have the editing CSS class.
            // Some browsers (at the moment, Firefox) automatically render the editing node duplication.
            var duplicateNodes = renderedNodes.filter(function (item) {
                return domClass.contains(item, this._editingCSSClass);
            }, this);

            if (duplicateNodes.length > 1) {
                // Remove the last one because it is the focused node after paste.
                // It is the node that we need to keep to place clean data after process.
                duplicateNodes.pop();
                redundantNodes = redundantNodes.concat(duplicateNodes);
            }

            return redundantNodes;
        },

        _setupEditingPoints: function () {
            // summary:
            //      Create new or get the existing instance of the editing points
            // tags:
            //      private

            this._beginEditingPoint = this._getEditingPoint("before") || this._createEditingPoint("before");
            this._endEditingPoint = this._getEditingPoint("after") || this._createEditingPoint("after");
        },

        _getEditingPoint: function (/*String*/position) {
            // summary:
            //      Get the created editing point by its CSS class from the given position.
            // position: [String]
            //      Accept only 2 values: "before" and "after"
            // tags:
            //      private

            return query("span." + this._getEditingPointClass(position), this._editingContainer)[0];
        },

        _getEditingPointClass: function (/*String*/position) {
            // summary:
            //      Get CSS class for editing point based on the given position (before/after) and the unique id
            // position: [String]
            //      Accept only 2 values: "before" and "after"
            // tags:
            //      private

            var editingCSSClass = (position === "before" ? this._beginEditingPointCSSClass : this._endEditingPointCSSClass);
            if (!epiString.isNullOrEmpty(this._editingKey)) {
                editingCSSClass += "-" + this._editingKey;
            }

            return editingCSSClass;
        },

        _createEditingPoint: function (/*String*/position) {
            // summary:
            //      Create a DOM node that used as an editing point. This DOM node is invisible.
            // position: [String]
            //      Accept only 2 values: "before" and "after"
            // tags:
            //      private

            var editingPoint = domConstruct.create("span",
                {
                    "class": this._getEditingPointClass(position),
                    "style": "display:none;position:absolute;left:-99em;"
                },
                this._editingNode,
                position === "before" ? "before" : "after");

            return editingPoint;
        },

        _destroyRedundantNodes: function (/*Array*/redundantNodes) {
            // summary:
            //      Remove all redundant nodes from rendered nodes after paste function.
            // redundantNodes: [Array]
            //      Collection of redundant DOM nodes
            // tags:
            //      private

            // Destroy all redundant nodes
            if (redundantNodes instanceof Array && redundantNodes.length > 0) {
                redundantNodes.forEach(domConstruct.destroy);
            }
        }

    });

});