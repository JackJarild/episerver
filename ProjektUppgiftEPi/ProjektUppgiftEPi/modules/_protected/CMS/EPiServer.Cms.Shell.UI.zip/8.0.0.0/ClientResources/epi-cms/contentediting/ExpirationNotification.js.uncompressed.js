﻿define("epi-cms/contentediting/ExpirationNotification", [
// dojo
    "dojo/_base/declare",

    "dojo/string",
// epi
    "epi/datetime",
    "epi/dependency",

    "epi-cms/ApplicationSettings",
    "epi-cms/contentediting/_ContentEditingNotification",

    "epi/i18n!epi/cms/nls/episerver.cms.widget.expirationeditor",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.versionstatus"
],

function (
// dojo
    declare,

    string,
// epi
    epiDatetime,
    dependency,

    ApplicationSettings,
    _ContentEditingNotification,

    expirationeditorResources,
    versionstatusResources
) {

    return declare([_ContentEditingNotification], {
        // summary:
        //      Provides notifications for content that has an expiration set.
        // tags:
        //      internal

        postscript: function () {
            this.inherited(arguments);

            this._notificationPeriod = ApplicationSettings.expirationNotificationPeriod;
            
            this._setupCommands();
        },

        _executeAction: function (/*Object*/context) {
            // summary:
            //      Updates the contentData for the notification with the latest model.
            // tags:
            //      protected, extension

            return context.contentData.properties.iversionable_expire;
        },

        _onExecuteSuccess: function (expireBlock) {
            // summary:
            //      Checks is the content data has an expired data and updates the notification property.

            var serverTime = epiDatetime.serverTime();
            
            var stopPublish = expireBlock ? expireBlock.stopPublish : null,
                expiration = new Date(stopPublish);

            var text = null;
            if (stopPublish && epiDatetime.isDateValid(expiration)) {
                if (new Date(serverTime.getTime() + this._notificationPeriod * 1000) > expiration) {
                    text = expiration < serverTime
                        ? versionstatusResources.expired
                        : string.substitute(expirationeditorResources.expiretimetext, [epiDatetime.timeToGo(expiration)]);
                }
            }
            if (!text) {
                this._setNotification(null); //clear notification
            } else {
                this._setNotification({ content: text, commands: [this._editingCommands.manageExpiration] });
            }
        },

        _viewModelValueHandler: null,

        _setupCommands: function () {
            if (!this._editingCommands) {
                this._editingCommands = dependency.resolve("epi.cms.contentEditing.command.Editing");
            }

            if (this._commandsWatchHandler) {
                this._commandsWatchHandler.unwatch();
            }

            var self = this;
            var handle = null;
            self._commandsWatchHandler = this._editingCommands.manageExpiration.watch("viewModel", function (name, oldViewModel, viewModel) {

                // remove the old observer
                if (self._viewModelValueHandler) {
                    self._viewModelValueHandler.unwatch();
                }

                self._viewModelValueHandler = viewModel.watch("value", function (name, oldValue, value) {
                    self._onExecuteSuccess(value);
                });
            });
        }

    });

});
